This dataset was downloaded from

https://www.kaggle.com/datasets/kaggle/recipe-ingredients-dataset

It was provided by Yummly.com for the Kaggle competition titled
"What's Cooking," that was hosted from September 9 to December 20,
2015.

https://www.kaggle.com/competitions/whats-cooking/

The competition and, presumably, the dataset are meant to be quoted as follows:

Wendy Kan. (2015). What's Cooking?. Kaggle. https://kaggle.com/competitions/whats-cooking

No license is explicitly provided to use the dataset, except to accept the
rules of the Kaggle competition:

https://www.kaggle.com/competitions/whats-cooking/rules#7-competition-data

One can do so by signing in to Kaggle.com (opening an account is free) and
formally participating in the competition in the form of a late submission.
However, since the competition is nominally over, doing so may be unnecessary.
Regardless, the dataset SHOULD NOT be considered public domain.
